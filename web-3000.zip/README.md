"# trading_platform" 
